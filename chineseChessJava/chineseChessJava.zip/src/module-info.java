/**
 * https://www.vogella.com/tutorials/EclipseGit/article.html
 */
/**
 * @author YANG Mattew
 *
 */
module chineseChess {
	requires java.desktop;
} //Test