package onlineTesting;
import game.*;

public class listsTest {

	public static void main(String[] args) {
		Board b = new Board();
		System.out.println(b);
	}

}
