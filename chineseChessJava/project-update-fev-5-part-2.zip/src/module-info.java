/**
 * https://www.vogella.com/tutorials/EclipseGit/article.html
 */
/**
 * @author YANG Mattew
 *
 */
module chineseChess {
	requires java.desktop;
	requires org.apache.logging.log4j;
	requires org.apache.logging.log4j.core;
}